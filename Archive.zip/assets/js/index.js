// const headingTitle = document.querySelector(".banner .heading-block .title");
// const valueTitle = headingTitle.getAttribute("data-title");
// const valueArray = valueTitle.split("");
// headingTitle.innerHTML = valueArray
//   .map((item) => {
//     return `<span>${item}</span>`;
//   })
//   .join("");

// headingChilds = document.querySelectorAll(".banner .heading-block .title span");
// headingChilds.forEach((child, index) => {
//   child.style.animation = `fadeIn ease-in-out 1s ${index * 0.5}s`;
// });
